from setuptools import setup, find_packages
setup(
    name='demo',
    version='0.1',
    packages=find_packages(),
    description='This is my demo test',
    author='爱立信',
    author_email='guess@qq.com',
    url='None',
    )